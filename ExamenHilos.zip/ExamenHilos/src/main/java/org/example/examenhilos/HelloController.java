package org.example.examenhilos;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class HelloController {
   @FXML
    private Button btnIniciar;

   @FXML
    private Button btnDetener;
}
