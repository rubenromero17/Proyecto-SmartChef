package org.example.examenhilos;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutionException;

public class Productor extends Thread {
    private BlockingQueue<String> queue;  //pasamos en el contructor el qeue, la ruta donde se encuentr el archivo y los paquetes que hemos precesados donde vamos a poner un contador s
    private String rutaArchivo;
    private Integer paquetesProcesados = 0;


    public Productor(BlockingQueue<String> queue, String rutaArchivo) {
        this.queue = queue;
        this.rutaArchivo = rutaArchivo;

    }

    public void run() {
        try (FileReader fr = new FileReader(rutaArchivo);
             BufferedReader br = new BufferedReader(fr)) {
            String linea;
            while ((linea = br.readLine()) != null) {
                queue.put(linea);
                paquetesProcesados++;
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Numeros de Paquetes Procesados: " + paquetesProcesados);
    }
}
