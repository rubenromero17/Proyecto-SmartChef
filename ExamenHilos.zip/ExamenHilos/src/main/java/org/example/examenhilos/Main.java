package org.example.examenhilos;

import javafx.application.Application;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {
    public static void main(String[] args) {
        String ruta = "src\\main\\java\\org\\example\\examenhilos\\telemetria.txt"; //aqui le damos un valor a la ruta que seria donde esta el archivo
        BlockingQueue<String> queue = new ArrayBlockingQueue<String>(1); //inicializamos el qeue



        Productor productor = new Productor(queue,ruta);//inizializamos el productor
        Consumidor consumidor = new Consumidor(queue);//inizializamos el consumidor
        productor.start();

        consumidor.start();
        System.out.println("Cuantos Contenian Alertas:  ");
        System.out.println("Estados Final de Mision:  ");
    }
}
