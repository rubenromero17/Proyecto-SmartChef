package org.example.examenhilos;

public class Telemetria {
    public Integer temp;
}
