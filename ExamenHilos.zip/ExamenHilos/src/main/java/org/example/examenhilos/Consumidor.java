package org.example.examenhilos;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;

public class Consumidor extends Thread {
    private BlockingQueue<String> queue;
    private Integer contadorConsumidor = 0;

    public Consumidor(BlockingQueue<String> queue, Integer contadorConsumidor) {
        this.queue = queue;
        this.contadorConsumidor = contadorConsumidor;
    }


    //hacemos el constructor con el qeue
    public Consumidor(BlockingQueue<String> queue) {
        this.queue = queue;
    }

    //aqui ponemos el codigo con lo que va a hacer el hilo a la hora de hacer el start
    @Override
    public void run() {
        try {
            while(true){
                String linea = queue.take();
                if(linea.equals("Poison Pill")){
                    System.out.println("Consumidor finalizado");
                    break;
                }
                contadorConsumidor++;
                System.out.println("Consumidor finalizado = " + contadorConsumidor );
                manejoProceso(linea); //aqui gestionamos lo que vamos a imprimir y las diferentes anomalias
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    //realizo este metodo para que me coje del txt las diferentes telemetrias por separado usando el Split gestionando los espacios
    //aparte hago un manejo de errores para en caso de superar lo indicado en el enunciado en los numero que son integers que de un mensaje de error
    //el tema esque no sabia como coger y dividir las letras y los numeros para que me detectara los valores y me ignore las palabras anteriores entonces
    // he decidido poner yo los lo que es y que se generen los valores desde el txt pero antes valorando las validaciones
    private synchronized void manejoProceso(String linea){
        String[] lineas = linea.split(" ");
        Integer temp =  Integer.parseInt(lineas[0]);
        Integer batt = Integer.parseInt(lineas[1]);
        Integer rad = (int) Double.parseDouble(lineas[2]);
        Integer vel =  Integer.parseInt(lineas[3]);
        
        String alertaTemp = "Alerta Sobrecalentamiento";
        String alertaBatt = "Alerta Bateria Baja";
        String alertaRad = "Alerta Radiacion Peligrosa";
        String alertaVel = "Alerta Rotacion Excesiva";
        List<String> Alertas = List.of(alertaBatt,alertaRad,alertaVel,alertaTemp);
        System.out.println("Monstrar Todas la Alertas: "+Alertas);
        System.out.println("Consumidor "+"Temp: "+temp+" Bat: "+batt+" Rad: "+rad+" Vel: "+vel + "--->" );
        if (temp > 85){
            System.out.println(alertaTemp);
        }
        if (batt < 30){
            System.out.println(alertaBatt);
        }
        if (rad < 1.5){
            System.out.println(alertaRad);
        }
        if (vel < 5){
            System.out.println(alertaVel);
        }
        System.out.println("-------------------------------------");
    }

}
