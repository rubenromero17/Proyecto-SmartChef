module org.example.examenhilos {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.examenhilos to javafx.fxml;
    exports org.example.examenhilos;
}